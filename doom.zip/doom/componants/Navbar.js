import React from 'react';
import { Link } from 'react-router-dom';

import './css/Navbar.css'


const Navbar=()=>{
  
  return (
       <div >
        <div className="navbar navbar-expand-lg navbar-light bg-light">
        
        <Link to="/" id="lala">Product Manager</Link>
        <li id="navv"><Link to="/Home" id="navvlink">Home</Link></li>
        <li id="navv"><Link to="/Features" id="navvlink">Features</Link></li>
        <li id="navv"><Link to="/Pricing" id="navvlink">Pricing</Link></li>
        
       
       </div>
       </div>
       
      );
    } 



export default Navbar;