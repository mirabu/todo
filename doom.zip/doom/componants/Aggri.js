import React from "react";
const Aggri=()=>{

return(
    <div className="App">
        <div className="container">
        <div className="card">
            <div className=""></div>
        </div> 
        </div>
    </div>

); 



}

export default Aggri;