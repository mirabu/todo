import '../componants/css/Accept.css'
import React,{useState } from 'react'; 
import {nanoid} from 'nanoid'

import data from "./mock-data.json";
import {AgGridColumn, AgGridReact} from 'ag-grid-react';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';


const Accept=()=>{
  const [contacts, setContacts] = useState(data);
  const [addFormData, setAddFormData] = useState({
    idea: "",
    namewala: "",
    price: "",
    
  });

  

  

  const handleAddFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...addFormData };
    newFormData[fieldName] = fieldValue;

    setAddFormData(newFormData);
  };

 

  const handleAddFormSubmit = (event) => {
    event.preventDefault();

    const newContact = {
      id: nanoid(),
      idea: addFormData.idea,
      namewala: addFormData.namewala,
      price: addFormData.price,
      
    };

    const newContacts = [...contacts, newContact];
    setContacts(newContacts);

  };

    
  
 

    return (
        <div className="container">
       
       <div className="card" >
  <div className="card-header">
    Add a New products
  </div>
  <div className="card-body">
  <div className="app-container">
      

      
      <form onSubmit={handleAddFormSubmit} className="form-inline">
        
        <div className='form-group'>
        <div id="field" className='form-group'>
        <span>Id</span>
        <input
          type="text"
          name="idea"
          required="required"
          className="form-control"
          onChange={handleAddFormChange}
          id="inputfield"
        /></div>


        <div id="field" className='form-group'>
        <span>Name</span>
        <input
          type="text"
          name="namewala"
          required="required"
          className="form-control"
          onChange={handleAddFormChange}
          id="inputfield"
        /></div>
        
        <div id="field" className='form-group'>
        <span>Price</span>
        <input
          type="text"
          name="price"
          required="required"
          className="form-control"
          onChange={handleAddFormChange}
          id="inputfield"
          
        />
        
        </div>
        <button type="submit" className="btn btn-primary " id="button">Add</button>
        </div>
        
      </form>
    </div>
  
</div>
        </div>


      <div className="container">
      <div className="card" id="seccard">
        <div className="card-header">
         Product List
        </div>

        <div className="card-body">
        <div className="ag-theme-alpine" style={{height: 400, width: 1000}}>
           <AgGridReact
             >
               <AgGridColumn field="Product_ID"></AgGridColumn>
               <AgGridColumn field="Product_Name"></AgGridColumn>
               <AgGridColumn field="Product_Price"></AgGridColumn>
               <AgGridColumn field="Action"></AgGridColumn>
           </AgGridReact>
       </div>
        </div>


      </div>
      </div> 











        </div>
      );

    
}

export default Accept;

