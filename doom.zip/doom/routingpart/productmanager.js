import Accept from "../componants/Accept";

const productmanager =()=>{
    return(
      <div className="app">

          <h1 id="products">Products</h1>
      <Accept/>
      </div>  
    );

}

export default productmanager;