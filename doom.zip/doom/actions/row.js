import EditableRow from "../componants/EditableRow";
import ReadOnlyRow from "../componants/ReadOnlyRow";
import React,{Fragment} from 'react';


const row=()=>{

     return(
     <div>
     { contacts.map((contact) => (
        <Fragment>
          {editContactId === contact.id ? (
            <EditableRow
              editFormData={editFormData}
              handleEditFormChange={handleEditFormChange}
              handleCancelClick={handleCancelClick}
            />
          ) : (
            <ReadOnlyRow
              contact={contact}
              handleEditClick={handleEditClick}
              handleDeleteClick={handleDeleteClick}
            />
          )}
        </Fragment>
      ))
}    
     </div>


    );
}

export default row;