import '../componants/css/Accept.css'
import React,{useState,Fragment} from 'react'; 
import {nanoid} from 'nanoid'
import ReadOnlyRow from './ReadOnlyRow';
import EditableRow from './EditableRow';
import data from "./mock-data.json";
import {AgGridColumn, AgGridReact} from 'ag-grid-react';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';


const Accept=()=>{
  const [contacts, setContacts] = useState(data);
  const [addFormData, setAddFormData] = useState({
    fullName: "",
    address: "",
    phoneNumber: "",
    email: "",
  });

  const [editFormData, setEditFormData] = useState({
    fullName: "",
    address: "",
    phoneNumber: "",
    
  });

  const [editContactId, setEditContactId] = useState(null);

  const handleAddFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...addFormData };
    newFormData[fieldName] = fieldValue;

    setAddFormData(newFormData);
  };

  const handleEditFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...editFormData };
    newFormData[fieldName] = fieldValue;

    setEditFormData(newFormData);
  };

  const handleAddFormSubmit = (event) => {
    event.preventDefault();

    const newContact = {
      id: nanoid(),
      fullName: addFormData.fullName,
      address: addFormData.address,
      phoneNumber: addFormData.phoneNumber,
      
    };

    const newContacts = [...contacts, newContact];
    setContacts(newContacts);
  };

  const handleEditFormSubmit = (event) => {
    event.preventDefault();

    const editedContact = {
      id: editContactId,
      fullName: editFormData.fullName,
      address: editFormData.address,
      phoneNumber: editFormData.phoneNumber,
      
    };

    const newContacts = [...contacts];

    const index = contacts.findIndex((contact) => contact.id === editContactId);

    newContacts[index] = editedContact;

    setContacts(newContacts);
    setEditContactId(null);
  };

  const handleEditClick = (event, contact) => {
    event.preventDefault();
    setEditContactId(contact.id);

    const formValues = {
      fullName: contact.fullName,
      address: contact.address,
      phoneNumber: contact.phoneNumber,
      
    };

    setEditFormData(formValues);
  };

  const handleCancelClick = () => {
    setEditContactId(null);
  };

  const handleDeleteClick = (contactId) => {
    const newContacts = [...contacts];

    const index = contacts.findIndex((contact) => contact.id === contactId);

    newContacts.splice(index, 1);

    setContacts(newContacts);
  };

    return (
        <div className="container">
       
       <div className="card" >
  <div className="card-header">
    Add a New products
  </div>
  <div className="card-body">
  <div className="app-container">
      

      
      <form onSubmit={handleAddFormSubmit} className="form-horizontal">
        
      <div className="row">
        <div className="form-group">
       
        <div id="field">
        <span>Id</span>
        <input
          type="text"
          name="fullName"
          required="required"
         
          onChange={handleAddFormChange}
          id="inputfield"
        /></div>


        <div id="field">
        <span>Name</span>
        <input
          type="text"
          name="address"
          required="required"
         
          onChange={handleAddFormChange}
          id="inputfield"
        /></div>
        
        <div id="field">
        <span>Price</span>
        <input
          type="text"
          name="phoneNumber"
          required="required"
         
          onChange={handleAddFormChange}
          id="inputfield"
          
        />
        </div>

       </div>
       </div>

        
       
        <button type="submit" className="btn btn-primary" id="button">Add</button>
      </form>
    </div>
  
</div>
        </div>


      <div className="container">
      <div className="card" id="seccard">
        <div className="card-header">
         Product List
        </div>

        <div className="card-body">
        <form onSubmit={handleEditFormSubmit}>
        <table className="table">
          <thead className="ag-theme-alpine">
            <tr>
              <th>Product ID</th>
              <th>Product Name</th>
              <th>Product Price</th>
              
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {contacts.map((contact) => (
              <Fragment>
                {editContactId === contact.id ? (
                  <EditableRow
                    editFormData={editFormData}
                    handleEditFormChange={handleEditFormChange}
                    handleCancelClick={handleCancelClick}
                  />
                ) : (
                  <ReadOnlyRow
                    contact={contact}
                    handleEditClick={handleEditClick}
                    handleDeleteClick={handleDeleteClick}
                  />
                )}
              </Fragment>
            ))}
          </tbody>
        </table>
      </form>
        </div>


      </div>
      </div> 











        </div>
      );

    
}

export default Accept;

